export interface Tab {
  title: string;
  name?: string;
  url?: string;
}
